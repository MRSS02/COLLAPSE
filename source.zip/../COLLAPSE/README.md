# COLLAPSE
Repository for our global game jam 2022, as a part of the FUBAjam 2022 group


#### Lisencing:

[Attribution-NonCommercial-ShareAlike 4.0 Creative Commons license](https://creativecommons.org/licenses/by-nc-sa/4.0/)
